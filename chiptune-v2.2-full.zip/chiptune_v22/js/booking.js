import { db } from "./firebase.js";
import { doc, setDoc, onSnapshot, getDoc } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-firestore.js";
import { resetTable } from "./common.js";


const ref = doc(db, "shop", "main");
let state = null;
let activeBookingId = null;
let bookingLocked = true;
let currentBookingDate = getTodayDate();
let calendarYear = new Date().getFullYear();
let calendarMonth = new Date().getMonth();
let selectedCalendarDate = currentBookingDate;
let bookingListOpen = false;
let moveBookingId = null;
let movePairs = [];
let draggingMoveFrom = null;
let moveLineRAF = null;
let lastMovePointer = null;
let runningPayTableIndex = null;
let dragTempLine = null;
let moveAreaRect = null;
let dragFromCenter = null;

const MOVE_LINE_COLORS = [
  "#e85d5d",
  "#2b6fc9",
  "#54a66b",
  "#ff9800",
  "#8e44ad",
  "#00a6a6"
];

const BOOKING_COLORS = [
  "#B7E4C7",
  "#A9DEF9",
  "#FFD6A5",
  "#D8B4FE",
  "#FFCAD4",
  "#FDFFB6",
  "#C7F9CC",
  "#FEC5BB",
  "#BDE0FE",
  "#E9C46A",
  "#CDEAC0",
  "#F1C0E8"
];

function getNextBookingColor(){
  const count = (state.bookings || []).length;
  return BOOKING_COLORS[count % BOOKING_COLORS.length];
}

function darkenColor(hex, amount = 28){
  hex = String(hex || "#B7E4C7").replace("#","");
  const num = parseInt(hex,16);

  let r = (num >> 16) - amount;
  let g = ((num >> 8) & 255) - amount;
  let b = (num & 255) - amount;

  r = Math.max(0,r);
  g = Math.max(0,g);
  b = Math.max(0,b);

  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b)
    .toString(16)
    .slice(1);
}

function getRunningColor(t){
  return t.activeColor || "#B7E4C7";
}

onSnapshot(ref, snap=>{
  if(!snap.exists()) return;

  state = snap.data();

  if(!state.bookings) state.bookings = [];
  if(!state.customers) state.customers = [];

  if(!Array.isArray(state.tables) || state.tables.length === 0){
    state.tables = Array.from({length:12},(_,i)=>({
      name:(i+1)+"号桌"
    }));
  }
  let needSave = false;

Promise.all(
  state.tables.map(async t=>{
    if(t.start && !t.recordId){
      await createOrUpdateTableRecord(t,{
        customerType: t.type === "booking" ? "booking" : "walkin",
        checkoutMethod: "补写开始计时账单"
      });
      needSave = true;
    }
  })
).then(()=>{
  if(needSave){
    save();
  }
});


try{
  renderList();
  renderBookingGrid();
}catch(e){
    alert("预约页面错误：" + e.message);
  }
});



function save(){
  setDoc(ref,state);
}

function getCustomerKey(name, phone){
  name = String(name || "").trim();
  phone = String(phone || "").slice(-4);

  if(!name || !phone) return "";

  return `${name}_${phone}`;
}

function addCustomerVisit({name, phone, packageIndex, tableIndexes, startTime, endTime}){
  const key = getCustomerKey(name, phone);
  if(!key) return;

  if(!state.customers) state.customers = [];

  let customer = state.customers.find(c=>c.key === key);

  if(!customer){
    customer = {
      key,
      name,
      phoneLast4:String(phone || "").slice(-4),
      visitCount:0,
      visits:[]
    };
    state.customers.push(customer);
  }

  const p = state.packages?.[packageIndex] || {};
  const tableNames = tableIndexes
    .map(i=>state.tables[i]?.name)
    .filter(Boolean)
    .join("、");

  customer.visitCount += 1;

  customer.visits.push({
    date: currentBookingDate,
    packageName: p.name || "",
    timeRange: `${startTime || "-"} - ${endTime || "-"}`,
    tableNames,
    createdAt: Date.now()
  });
}

async function createOrUpdateTableRecord(t, {
  customerType = "walkin",
  checkoutMethod = "开始计时"
} = {}){

  const p = state.packages?.[Number(t.packageIndex || 0)] || {};
  const paidJPY = Number(p.price || 0);
  const now = Date.now();

  let record = null;

  if(t.recordId){
    const snap = await getDoc(doc(db, "records", t.recordId));
    if(snap.exists()){
      record = snap.data();
    }
  }

  if(!record){
    record = {
      id:"rec_" + now + "_" + Math.random().toString(36).slice(2,8),
      timestamp:now,
      time:new Date(now).toLocaleString(),
      receiptImage:"",
      receiptFileName:""
    };

    t.recordId = record.id;
  }

  record.timestamp = record.timestamp || now;
  record.time = record.time || new Date(now).toLocaleString();

  record.tableName = t.name;
  record.customerName = t.customer?.name || "";
  record.phoneLast4 = t.customer?.phoneLast4 || "";
  record.customerType = customerType;

  record.packageName = p.name || "";
  record.packageMinutes = p.unlimited ? "不限时" : p.minutes;
  record.packagePrice = paidJPY;

  record.extraMinutes = Math.floor(Number(t.extra || 0) / 60000);
  record.extensionAmount = 0;
  record.originalJPY = paidJPY;

  record.paidJPY = paidJPY;
  record.dueJPY = 0;
  record.totalJPY = paidJPY;
  record.totalRMB = Math.floor(paidJPY * 0.044);

  record.pay = t.pay || "未记录";
  record.currency = t.currency || "日元";
  record.payTiming = "prepaid";

  record.paidStatus = "已结清";
  record.recordType = "prepaid";
  record.checkoutMethod = checkoutMethod;
  record.roundRule = "不抹零";

  t.paidJPY = paidJPY;
  t.paidRMB = Math.floor(paidJPY * 0.044);
  t.paidAt = now;

  await setDoc(doc(db, "records", record.id), record);

  return record;
}


function getTodayDate(){
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth()+1).padStart(2,"0");
  const day = String(d.getDate()).padStart(2,"0");
  return `${y}-${m}-${day}`;
}

let selecting = false;
let selection = null;

const DEFAULT_BUSINESS_HOURS = {
  weekdayOpen: 12,
  weekdayClose: 22,
  weekendOpen: 10,
  weekendClose: 22
};

const SLOT_MINUTES = 30;

function getBusinessHours(){
  const hours = state.businessHours || DEFAULT_BUSINESS_HOURS;
  const d = new Date(currentBookingDate);
  const day = d.getDay();
  const isWeekend = day === 0 || day === 6;

  return {
    open: isWeekend ? Number(hours.weekendOpen || 10) : Number(hours.weekdayOpen || 12),
    close: isWeekend ? Number(hours.weekendClose || 22) : Number(hours.weekdayClose || 22)
  };
}

function getSlots(){
  const {open, close} = getBusinessHours();
  const slots = [];

  for(let h = open; h < close; h++){
    slots.push(`${String(h).padStart(2,"0")}:00`);
    slots.push(`${String(h).padStart(2,"0")}:30`);
  }

  slots.push(`${String(close).padStart(2,"0")}:00`);

  return slots;
}



function timeToMinutes(time){
  const [h,m] = String(time || "00:00").split(":").map(Number);
  return h * 60 + m;
}

function findPackageIndexByDuration(startTime,endTime){
  const minutes =
    timeToMinutes(endTime) - timeToMinutes(startTime);

  const packages = state.packages || [];

  const d = new Date(currentBookingDate);
  const day = d.getDay();
  const isWeekend = day === 0 || day === 6;

  const exactIndex = packages.findIndex(p=>{
    return !p.unlimited &&
           Number(p.minutes || 0) === minutes;
  });

  if(exactIndex >= 0){
    return exactIndex;
  }

  if(!isWeekend){
    const unlimitedIndex = packages.findIndex(p=>{
      return p.unlimited;
    });

    if(unlimitedIndex >= 0){
      return unlimitedIndex;
    }
  }

  return 0;
}

function isTableBusyAtSlot(t, rowIndex){
  if(!t.start) return false;

  const slots = getSlots();
  const slotTime = slots[rowIndex];
  if(!slotTime) return false;

  const [hh, mm] = slotTime.split(":").map(Number);

  const slotDate = new Date(currentBookingDate);
  slotDate.setHours(hh, mm, 0, 0);

  const slotStart = slotDate.getTime();
  const slotEnd = slotStart + SLOT_MINUTES * 60000;

  const p = state.packages?.[t.packageIndex] || {};
  const busyStart = Number(t.start);

  let busyEnd;

  if(p.unlimited || Number(p.minutes || 0) === 0){
    const closeDate = new Date(currentBookingDate);
    closeDate.setHours(getBusinessHours().close, 0, 0, 0);
    busyEnd = closeDate.getTime();
  }else{
    const baseMinutes = Number(p.minutes || 0);
    const extraMinutes = Number(t.extra || 0) / 60000;
    busyEnd = busyStart + (baseMinutes + extraMinutes) * 60000;
  }

  return slotStart < busyEnd && slotEnd > busyStart;
}

function formatShortTime(ms){
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  return h > 0 ? `${h}:${String(m).padStart(2,"0")}` : `${m}分`;
}

function getTableStatusText(t){
  if(!t.start) return "";

  const p = state.packages?.[t.packageIndex] || {};
  const elapsed = Date.now() - Number(t.start);

  if(p.unlimited || Number(p.minutes || 0) === 0){
    return {
      text:`已用 ${formatShortTime(elapsed)}`,
      className:"slot-running"
    };
  }

  const limit = Number(p.minutes || 0) * 60000 + Number(t.extra || 0);
  const remain = limit - elapsed;

  if(remain <= 0){
    return {
      text:`超时 ${formatShortTime(Math.abs(remain))}`,
      className:"slot-overtime"
    };
  }

  if(remain <= 10 * 60000){
    return {
      text:`剩 ${formatShortTime(remain)}`,
      className:"slot-warning"
    };
  }

  return {
    text:`剩 ${formatShortTime(remain)}`,
    className:"slot-normal"
  };
}


function isTableUsedAtSlot(t,rowIndex){
  if(!t.start) return false;

  const slots = getSlots();
  const slotTime = slots[rowIndex];
  if(!slotTime) return false;

  const [hh,mm] = slotTime.split(":").map(Number);

  const slotDate = new Date(currentBookingDate);
  slotDate.setHours(hh,mm,0,0);

  const slotStart = slotDate.getTime();
  const slotEnd = slotStart + SLOT_MINUTES * 60000;

  const usedStart = Number(t.start);
  const usedEnd = Number(t.pausedAt || Date.now());

  return slotStart < usedEnd && slotEnd > usedStart;
}

function isPastTimeSlot(rowIndex){
  const slots = getSlots();
  const slotTime = slots[rowIndex];
  if(!slotTime) return false;

  const [hh, mm] = slotTime.split(":").map(Number);

  const slotDate = new Date(currentBookingDate);
  slotDate.setHours(hh, mm + SLOT_MINUTES, 0, 0);

  return slotDate.getTime() <= Date.now();
}

function renderBookingGrid(){
  if(!state) return;

  const box = document.getElementById("bookingGrid");
  if(!box){
    alert("找不到 bookingGrid");
    return;
  }

  if(!Array.isArray(state.tables) || state.tables.length === 0){
    alert("没有桌位数据");
    return;
  }

  const slots = getSlots();

  const title = document.getElementById("bookingDateTitle");
  if(title){
    title.innerText =
      currentBookingDate === getTodayDate()
        ? "今日预约时间表"
        : currentBookingDate + " 预约时间表";
  }

  box.innerHTML = `
    <div class="booking-grid" style="grid-template-columns:80px repeat(${state.tables.length}, 1fr);">
      <div class="grid-head time-head">时间</div>

      ${state.tables.map((t,tableIndex)=>{
  const usingToday = slots.some((_,rowIndex)=>{
    return isTableBusyAtSlot(t,rowIndex);
  });

  return `
    <div class="grid-head ${usingToday ? "table-using" : ""}">
      ${t.name}${usingToday ? " 使用中" : ""}
    </div>
  `;
}).join("")}

${slots.slice(0,-1).map((time,rowIndex)=>`
        <div class="time-cell ${isPastTimeSlot(rowIndex) ? "past-time-cell" : ""}">
          ${time}
        </div>
        ${state.tables.map((t,tableIndex)=>{

          const busy = isTableBusyAtSlot(t,rowIndex);
          const used = isTableUsedAtSlot(t,rowIndex);
          const statusInfo = busy ? getTableStatusText(t) : null;
return `
  <div
      class="slot-cell ${isPastTimeSlot(rowIndex) ? "past-slot" : ""} ${busy ? "disabled-slot" : ""} ${used ? "used-slot" : ""} ${statusInfo?.className || ""}"
      data-table="${tableIndex}"
      data-row="${rowIndex}"

      ${busy || bookingLocked ? "" : `
  onpointerdown="startSelectSlot(event,${tableIndex},${rowIndex})"
  onpointermove="moveSelectByPoint(event)"
  onpointerup="endSelectSlot(event)"
  onpointercancel="endSelectSlot(event)"
`}

    >
</div>
  `;
}).join("")}
`).join("")}
    </div>
  `;

  drawExistingBookings();
  drawRunningTables();
  updateBookingLockUI();

}

function updateBookingLockUI(){
  const btn = document.getElementById("bookingLockBtn");
  const hint = document.getElementById("bookingLockHint");
  const grid = document.getElementById("bookingGrid");

  if(btn){
    btn.innerText = bookingLocked ? "🔒 已锁定" : "🔓 已解锁";
    btn.className = bookingLocked ? "btn-danger" : "btn-success";
  }

  if(hint){
    hint.innerText = bookingLocked
      ? "当前为锁定状态，只能查看，不能创建/修改预约"
      : "当前为解锁状态，可以创建/修改预约，操作完成后请重新锁定";

    hint.className = bookingLocked
      ? "booking-lock-hint locked"
      : "booking-lock-hint unlocked";
  }

  if(grid){
    grid.classList.toggle("locked-grid", bookingLocked);
    grid.classList.toggle("unlocked-grid", !bookingLocked);
  }
}

function toggleBookingLock(){
  bookingLocked = !bookingLocked;
  updateBookingLockUI();
  renderBookingGrid();
}

function renderList(){
  const box = document.getElementById("list");
  const summary = document.getElementById("bookingSummary");
  const btn = document.getElementById("bookingListToggleBtn");

  if(!box) return;

  const bookings = (state.bookings || [])
    .filter(b=>(b.date || getTodayDate()) === currentBookingDate)
    .sort((a,b)=>String(a.startTime || "99:99").localeCompare(String(b.startTime || "99:99")));

  const checked = bookings.filter(b=>b.checkedIn).length;
  const waiting = bookings.filter(b=>!b.checkedIn).length;

  const tableTotal = bookings.reduce((sum,b)=>{
    return sum + (b.tableIndexes || [b.tableIndex])
      .filter(v=>v !== undefined && v !== null)
      .length;
  },0);

  if(summary){
    summary.innerHTML =
      `未到店：${waiting}组｜已到店：${checked}组｜预约桌数：${tableTotal}桌`;
  }

  if(btn){
    btn.innerText = bookingListOpen ? "收起" : "展开";
  }

  box.style.display = bookingListOpen ? "block" : "none";

  if(bookings.length === 0){
    box.innerHTML = `<p style="color:#8a8174;">这一天暂无预约</p>`;
    return;
  }

  box.innerHTML = bookings.map(b=>{
    const tables = (b.tableIndexes || [b.tableIndex])
      .filter(v=>v !== undefined && v !== null)
      .map(idx=>state.tables[Number(idx)]?.name)
      .filter(Boolean)
      .join("、");

    return `
      <div class="booking-list-item ${b.checkedIn ? "booking-list-done" : "booking-list-wait"}">
        <div class="booking-list-time">
          ${b.startTime || "-"} - ${b.endTime || "-"}
        </div>

        <div class="booking-list-main">
          <strong>${b.name || "-"}</strong>
          <span>${String(b.phone || "").slice(-4) || "-"}</span>
        </div>

        <div class="booking-list-sub">
          桌位：${tables || "-"}｜${b.checkedIn ? "已到店" : "未到店"}
        </div>

        ${bookingLocked ? "" : `
          <div class="action-row" style="margin-top:10px;">
            <button class="btn-success" onclick="openCheckInSelectModal(${b.id})">到店开始</button>
            <button class="btn-main" onclick="openBookingAction(${b.id})">修改</button>
            <button class="btn-ghost" onclick="openMoveTableModal(${b.id})">移动桌位</button>
            <button class="btn-danger" onclick="cancelBookingById(${b.id})">取消</button>
          </div>
        `}
      </div>
    `;
  }).join("");
}

function toggleBookingList(){
  bookingListOpen = !bookingListOpen;
  renderList();
}

function checkInBookingById(id){
  activeBookingId = id;
  checkInBooking();
}

function cancelBookingById(id){
  activeBookingId = id;
  cancelBooking();
}

function hasBookingConflict(targetIndex, booking, excludeBookingId){
  const target = Number(targetIndex);

  const startA = timeToMinutes(booking.startTime);
  const endA = timeToMinutes(booking.endTime);

  return (state.bookings || []).some(b=>{
    if(Number(b.id) === Number(excludeBookingId)) return false;
    if((b.date || currentBookingDate) !== currentBookingDate) return false;

    const indexes = (b.tableIndexes || [b.tableIndex])
      .filter(v=>v !== undefined && v !== null)
      .map(Number);

    if(!indexes.includes(target)) return false;

    const startB = timeToMinutes(b.startTime);
    const endB = timeToMinutes(b.endTime);

    return startA < endB && endA > startB;
  });
}

function openMoveTableModal(id){
  if(!id) id = activeBookingId;

  const b = getBookingById(id);
  if(!b) return;

  moveBookingId = id;
  movePairs = [];
  draggingMoveFrom = null;

  const bookingIndexes = (b.tableIndexes || [b.tableIndex])
    .filter(v=>v !== undefined && v !== null)
    .map(Number);

  document.getElementById("moveTableInfo").innerHTML = `
    客人：${b.name || "-"} ${String(b.phone || "").slice(-4) || ""}<br>
    预约时间：${b.startTime || "-"} - ${b.endTime || "-"}<br>
    当前桌位：${bookingIndexes.map(i=>state.tables[i]?.name).filter(Boolean).join("、")}
  `;

  document.getElementById("moveLineArea").innerHTML = `
    <svg id="moveSvg"></svg>

    <div class="move-row-title">按住要移动的桌位，拖到下面目标桌位</div>
    <div id="moveFromTableBox" class="move-drag-grid">
      ${bookingIndexes.map(i=>{
        const running = state.tables[i]?.start ? "已开始" : "未开始";

        return `
          <button
            class="move-table-btn move-from-btn"
            data-index="${i}"
            id="move-from-${i}"
            onpointerdown="startMoveDrag(event,${i})"
          >
            ${state.tables[i]?.name || (i+1)+"号桌"}<br>
            <small>${running}</small>
          </button>
        `;
      }).join("")}
    </div>

    <div class="move-row-title">拖到这里选择目标桌位</div>
    <div id="moveToTableBox" class="move-drag-grid">
      ${state.tables.map((t,i)=>{
        const isSameBookingTable = bookingIndexes.includes(i);
        const occupied = !!t.start && !isSameBookingTable;
        const conflict = hasBookingConflict(i, b, b.id) && !isSameBookingTable;

        let disabled = occupied || conflict;
        let sub = "可移动";

        if(occupied) sub = "使用中";
        else if(conflict) sub = "已有预约";
        else if(isSameBookingTable) sub = "当前预约桌";

        return `
          <button
            class="move-table-btn move-to-btn ${disabled ? "disabled" : ""}"
            data-index="${i}"
            id="move-to-${i}"
            ${disabled ? "disabled" : ""}
          >
            ${t.name}<br>
            <small>${sub}</small>
          </button>
        `;
      }).join("")}
    </div>
  `;

  document.getElementById("moveTableModalBg").style.display = "block";
  setTimeout(drawMoveLines, 50);
}

function startMoveDrag(e, fromIndex){
  e.preventDefault();

  draggingMoveFrom = Number(fromIndex);

  document.querySelectorAll(".move-from-btn")
    .forEach(btn=>btn.classList.remove("dragging"));

  const fromEl = document.getElementById("move-from-" + fromIndex);
  fromEl?.classList.add("dragging");

  const area = document.getElementById("moveLineArea");
  const svg = document.getElementById("moveSvg");
  if(!area || !svg || !fromEl) return;

  moveAreaRect = area.getBoundingClientRect();

  const r = fromEl.getBoundingClientRect();
  dragFromCenter = {
    x: r.left + r.width / 2 - moveAreaRect.left,
    y: r.top + r.height / 2 - moveAreaRect.top
  };

  const ns = "http://www.w3.org/2000/svg";
  dragTempLine = document.createElementNS(ns, "line");

  const color = MOVE_LINE_COLORS[movePairs.length % MOVE_LINE_COLORS.length];

  dragTempLine.setAttribute("x1", dragFromCenter.x);
  dragTempLine.setAttribute("y1", dragFromCenter.y);
  dragTempLine.setAttribute("x2", dragFromCenter.x);
  dragTempLine.setAttribute("y2", dragFromCenter.y);
  dragTempLine.setAttribute("stroke", color);
  dragTempLine.setAttribute("stroke-width", "5");
  dragTempLine.setAttribute("stroke-linecap", "round");
  dragTempLine.setAttribute("stroke-dasharray", "8 6");

  svg.appendChild(dragTempLine);

  window.addEventListener("pointermove", moveDragLine, {passive:false});
  window.addEventListener("pointerup", endMoveDrag);
}


function moveDragLine(e){
  if(draggingMoveFrom === null) return;
  if(!dragTempLine || !moveAreaRect) return;

  e.preventDefault();

  const x = e.clientX - moveAreaRect.left;
  const y = e.clientY - moveAreaRect.top;

  dragTempLine.setAttribute("x2", x);
  dragTempLine.setAttribute("y2", y);
}


function endMoveDrag(e){
  if(draggingMoveFrom === null) return;

  const target = document.elementFromPoint(e.clientX, e.clientY);
  const toBtn = target?.closest?.(".move-to-btn");

  if(toBtn && !toBtn.disabled){
    const toIndex = Number(toBtn.dataset.index);

    if(draggingMoveFrom === toIndex){
      alert("新桌位不能和原桌位一样");
    }else{
      movePairs = movePairs.filter(p=>{
        return p.from !== draggingMoveFrom && p.to !== toIndex;
      });

      movePairs.push({
        from: draggingMoveFrom,
        to: toIndex
      });
    }
  }

  document.querySelectorAll(".move-from-btn")
    .forEach(btn=>btn.classList.remove("dragging"));

  draggingMoveFrom = null;

  window.removeEventListener("pointermove", moveDragLine);
window.removeEventListener("pointerup", endMoveDrag);

lastMovePointer = null;

if(moveLineRAF){
  cancelAnimationFrame(moveLineRAF);
  moveLineRAF = null;
}

if(dragTempLine){
  dragTempLine.remove();
  dragTempLine = null;
}

moveAreaRect = null;
dragFromCenter = null;

drawMoveLines();


}

function drawMoveLines(pointerX = null, pointerY = null){
  const svg = document.getElementById("moveSvg");
  const area = document.getElementById("moveLineArea");
  if(!svg || !area) return;

  const rect = area.getBoundingClientRect();
  const ns = "http://www.w3.org/2000/svg";

  const nodes = [];

  function centerOf(el){
    const r = el.getBoundingClientRect();
    return {
      x: r.left + r.width / 2 - rect.left,
      y: r.top + r.height / 2 - rect.top
    };
  }

  document.querySelectorAll(".move-table-btn.selected")
    .forEach(btn=>btn.classList.remove("selected"));

  movePairs.forEach((pair,idx)=>{
    const fromEl = document.getElementById("move-from-" + pair.from);
    const toEl = document.getElementById("move-to-" + pair.to);
    if(!fromEl || !toEl) return;

    fromEl.classList.add("selected");
    toEl.classList.add("selected");

    const a = centerOf(fromEl);
    const b = centerOf(toEl);
    const color = MOVE_LINE_COLORS[idx % MOVE_LINE_COLORS.length];

    const line = document.createElementNS(ns, "line");
    line.setAttribute("x1", a.x);
    line.setAttribute("y1", a.y);
    line.setAttribute("x2", b.x);
    line.setAttribute("y2", b.y);
    line.setAttribute("stroke", color);
    line.setAttribute("stroke-width", "5");
    line.setAttribute("stroke-linecap", "round");

    nodes.push(line);
  });

  if(draggingMoveFrom !== null && pointerX !== null && pointerY !== null){
    const fromEl = document.getElementById("move-from-" + draggingMoveFrom);

    if(fromEl){
      const a = centerOf(fromEl);
      const color = MOVE_LINE_COLORS[movePairs.length % MOVE_LINE_COLORS.length];

      const line = document.createElementNS(ns, "line");
      line.setAttribute("x1", a.x);
      line.setAttribute("y1", a.y);
      line.setAttribute("x2", pointerX - rect.left);
      line.setAttribute("y2", pointerY - rect.top);
      line.setAttribute("stroke", color);
      line.setAttribute("stroke-width", "5");
      line.setAttribute("stroke-linecap", "round");
      line.setAttribute("stroke-dasharray", "8 6");

      nodes.push(line);
    }
  }

  svg.replaceChildren(...nodes);
}

function confirmMoveTable(){
  const b = getBookingById(moveBookingId);
  if(!b) return;

  if(movePairs.length === 0){
    alert("请先拖线选择要移动的桌位");
    return;
  }

  const bookingIndexes = (b.tableIndexes || [b.tableIndex])
    .filter(v=>v !== undefined && v !== null)
    .map(Number);

  for(const pair of movePairs){
    if(!bookingIndexes.includes(pair.from)){
      alert("有原桌位不属于这个预约");
      return;
    }

    if(pair.from === pair.to){
      alert("新桌位不能和原桌位一样");
      return;
    }

    const toTable = state.tables[pair.to];

    if(toTable?.start){
      alert(`${toTable.name} 正在使用中，不能移动`);
      return;
    }

    if(hasBookingConflict(pair.to, b, b.id)){
      alert(`${toTable.name} 在这个时间段已有预约，不能移动`);
      return;
    }
  }

  movePairs.forEach(pair=>{
    const fromTable = state.tables[pair.from];
    const toTable = state.tables[pair.to];

    if(fromTable?.start){
      const oldFromName = fromTable.name;
      const oldToName = toTable.name;

      state.tables[pair.to] = {
        ...fromTable,
        name: oldToName
      };

      state.tables[pair.from] = resetTable(oldFromName);
    }
  });

  b.tableIndexes = bookingIndexes.map(i=>{
    const pair = movePairs.find(p=>p.from === i);
    return pair ? pair.to : i;
  });

  if(b.checkedInTableIndexes){
    b.checkedInTableIndexes = b.checkedInTableIndexes
      .map(Number)
      .map(i=>{
        const pair = movePairs.find(p=>p.from === i);
        return pair ? pair.to : i;
      });
  }

  delete b.tableIndex;

  save();
  closeMoveTableModal();
  renderBookingGrid();
  renderList();

  alert("桌位已移动");
}


function closeMoveTableModal(){
  document.getElementById("moveTableModalBg").style.display = "none";
  moveBookingId = null;
  movePairs = [];
  draggingMoveFrom = null;
}

function startSelectSlot(e,tableIndex,rowIndex){
  if(bookingLocked) return;
  if(isTableBusyAtSlot(state.tables[tableIndex], rowIndex)) return;

  e.preventDefault();

  selecting = true;

  selection = {
    startTableIndex: tableIndex,
    endTableIndex: tableIndex,
    startRow: rowIndex,
    endRow: rowIndex
  };

  highlightSelection();
}


function moveSelectSlot(e,tableIndex,rowIndex){
  if(!selecting || !selection) return;
  if(tableIndex !== selection.tableIndex) return;

  selection.endRow = rowIndex;
  highlightSelection();
}

function moveSelectByPoint(e){
  if(!selecting || !selection) return;

  const target = document.elementFromPoint(e.clientX, e.clientY);
  if(!target || !target.classList.contains("slot-cell")) return;

  const tableIndex = Number(target.dataset.table);
  const rowIndex = Number(target.dataset.row);

  selection.endTableIndex = tableIndex;
  selection.endRow = rowIndex;

  highlightSelection();
}


function endSelectSlot(e){
  if(!selecting || !selection) return;

  selecting = false;

  const startRow = Math.min(selection.startRow, selection.endRow);
  const endRow = Math.max(selection.startRow, selection.endRow) + 1;

  const startTable = Math.min(selection.startTableIndex, selection.endTableIndex);
  const endTable = Math.max(selection.startTableIndex, selection.endTableIndex);

  const slots = getSlots();

  const startTime = slots[startRow];
  const endTime = slots[endRow] || `${getBusinessHours().close}:00`;

  const tableNames = [];

  for(let i=startTable; i<=endTable; i++){
    tableNames.push(state.tables[i].name);
  }

  document.getElementById("selectedRangeText").innerText =
    `${tableNames.join("、")}｜${startTime} - ${endTime}`;

  const tip = document.getElementById("selectionTip");
if(tip) tip.style.display = "none";

fillModalPackages();

const autoPackageIndex = findPackageIndexByDuration(startTime, endTime);
const modalPackage = document.getElementById("modalPackage");

if(modalPackage){
  modalPackage.value = String(autoPackageIndex);
}

const modalType = document.getElementById("modalType");
if(modalType) modalType.value = "booking";

toggleModalType();


  document.getElementById("bookingModalBg").style.display = "block";
}


function updateSelectionTip(){
  let tip = document.getElementById("selectionTip");

  if(!tip){
    tip = document.createElement("div");
    tip.id = "selectionTip";
    tip.className = "selection-tip";
    document.body.appendChild(tip);
  }

  if(!selection){
    tip.style.display = "none";
    return;
  }

  const startRow = Math.min(selection.startRow, selection.endRow);
  const endRow = Math.max(selection.startRow, selection.endRow) + 1;

  const minutes = (endRow - startRow) * SLOT_MINUTES;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;

  const durationText =
    hours > 0
      ? `${hours}小时${mins ? mins + "分钟" : ""}`
      : `${mins}分钟`;

  const slots = getSlots();
  const startTime = slots[startRow];
  const endTime = slots[endRow] || `${getBusinessHours().close}:00`;

  const tableCount =
    Math.abs(selection.endTableIndex - selection.startTableIndex) + 1;

  tip.innerHTML =
    `<b>${tableCount}桌｜${durationText}</b><br>${startTime} - ${endTime}`;

  const cell = document.querySelector(
    `.slot-cell[data-table="${selection.endTableIndex}"][data-row="${selection.endRow}"]`
  );

  if(cell){
    const rect = cell.getBoundingClientRect();
    tip.style.left = rect.right + 8 + "px";
    tip.style.top = rect.top + "px";
    tip.style.display = "block";
  }else{
    tip.style.display = "none";
  }
}



function highlightSelection(){
  document.querySelectorAll(".slot-cell.selecting").forEach(el=>{
    el.classList.remove("selecting");
  });

  if(!selection) return;

  const startRow = Math.min(selection.startRow, selection.endRow);
  const endRow = Math.max(selection.startRow, selection.endRow);

  const startTable = Math.min(selection.startTableIndex, selection.endTableIndex);
  const endTable = Math.max(selection.startTableIndex, selection.endTableIndex);

  document.querySelectorAll(".slot-cell").forEach(el=>{
    const table = Number(el.dataset.table);
    const row = Number(el.dataset.row);

    if(
      table >= startTable &&
      table <= endTable &&
      row >= startRow &&
      row <= endRow
    ){
      el.classList.add("selecting");
    }
  });
  updateSelectionTip();
}

function toggleModalType(){
  const type = document.getElementById("modalType")?.value || "booking";
  const packageBox = document.getElementById("modalPackageBox");
  const btn = document.getElementById("modalConfirmBtn");

  if(packageBox){
    packageBox.style.display = type === "walkin" ? "block" : "none";
  }

  if(btn){
    btn.innerText = type === "walkin" ? "开始计时" : "确认预约";
  }
}

function fillModalPackages(){
  const box = document.getElementById("modalPackage");
  if(!box) return;

  box.innerHTML = (state.packages || []).map((p,i)=>`
    <option value="${i}">
      ${p.name}｜${p.unlimited ? "不限时" : p.minutes + "分钟"}｜¥${p.price}
    </option>
  `).join("");
}

  async function confirmGridBooking(){
  if(!selection) return;

  const type = document.getElementById("modalType")?.value || "booking";
  const name = document.getElementById("modalName").value.trim();
  const phone = document.getElementById("modalPhone").value.trim();

  const slots = getSlots();

  const start = Math.min(selection.startRow, selection.endRow);
  const end = Math.max(selection.startRow, selection.endRow) + 1;

  const startTable = Math.min(selection.startTableIndex, selection.endTableIndex);
  const endTable = Math.max(selection.startTableIndex, selection.endTableIndex);

  const tableIndexes = Array.from(
    { length: endTable - startTable + 1 },
    (_,idx)=>startTable + idx
  );

  const busyTables = tableIndexes.filter(idx=>state.tables[idx]?.start);

  if(busyTables.length){
    alert("以下桌位正在使用中，不能操作：\n" + busyTables.map(i=>state.tables[i].name).join("、"));
    return;
  }

  const startTime = slots[start];
  const endTime = slots[end] || `${getBusinessHours().close}:00`;

  if(type === "walkin"){
    const packageIndex = Number(document.getElementById("modalPackage")?.value || 0);
    const now = Date.now();
    const walkinColor = getNextBookingColor();
      for(const idx of tableIndexes){
      const t = state.tables[idx];
      if(!t) return;

      t.type = "walkin";
      t.activeColor = walkinColor;
      t.bookingId = null;
      t.packageIndex = packageIndex;
      t.pay = "";
      t.currency = "日元";
      t.customer = {
        name,
        phoneLast4:String(phone || "").slice(-4)
      };
      t.start = now;
      t.pausedAt = null;
      t.extra = 0;
      t.alerted = false;
      t.alerting = false;
      t.lastAction = "start";
      await createOrUpdateTableRecord(t, {
  customerType:"walkin",
  checkoutMethod:"Walk-in开始计时"
});
    }

    save();

    closeBookingModal();
    renderBookingGrid();
    renderList();

    alert("Walk-in 已开始计时");
    return;
  }


  const packageIndex = findPackageIndexByDuration(startTime,endTime);

  const booking = {
    id: Date.now(),
    date: currentBookingDate,
    color: getNextBookingColor(),
    name,
    phone,
    tableIndexes,
    startTime,
    endTime,
    packageIndex,
    checkedIn:false,
    checkInTime:null,
    checkInTimeText:"",
    cancelled:false,
  };

  state.bookings.push(booking);

  save();

  closeBookingModal();
  renderBookingGrid();
  renderList();
}

function closeBookingModal(){
  document.getElementById("bookingModalBg").style.display = "none";
  document.getElementById("modalName").value = "";
  document.getElementById("modalPhone").value = "";

  document.querySelectorAll(".slot-cell.selecting").forEach(el=>{
    el.classList.remove("selecting");
  });

  selecting = false;
  selection = null;
  const tip = document.getElementById("selectionTip");
if(tip) tip.style.display = "none";
  const modalType = document.getElementById("modalType");
if(modalType) modalType.value = "booking";

const packageBox = document.getElementById("modalPackageBox");
if(packageBox) packageBox.style.display = "none";

const btn = document.getElementById("modalConfirmBtn");
if(btn) btn.innerText = "确认预约";
}

function openDatePicker(){
  const d = new Date(currentBookingDate);
  calendarYear = d.getFullYear();
  calendarMonth = d.getMonth();
  selectedCalendarDate = currentBookingDate;

  document.getElementById("datePickerModalBg").style.display = "block";
  renderCustomCalendar();
}


function getBookingDates(){
  const set = new Set();

  (state.bookings || []).forEach(b=>{
    if(b.date) set.add(b.date);
  });

  return set;
}

function renderCustomCalendar(){
  const box = document.getElementById("calendarGrid");
  const title = document.getElementById("calendarTitle");
  if(!box || !title) return;

  title.innerText = `${calendarYear}年${calendarMonth + 1}月`;

  const bookingDates = getBookingDates();

  const first = new Date(calendarYear, calendarMonth, 1);
  const last = new Date(calendarYear, calendarMonth + 1, 0);
  const startDay = first.getDay();
  const days = last.getDate();

  let html = `
    <div class="cal-week">日</div>
    <div class="cal-week">一</div>
    <div class="cal-week">二</div>
    <div class="cal-week">三</div>
    <div class="cal-week">四</div>
    <div class="cal-week">五</div>
    <div class="cal-week">六</div>
  `;

  for(let i=0;i<startDay;i++){
    html += `<div></div>`;
  }

  for(let d=1; d<=days; d++){
    const dateStr =
      `${calendarYear}-${String(calendarMonth+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;

    const hasBooking = bookingDates.has(dateStr);
    const selected = selectedCalendarDate === dateStr;

const today = dateStr === getTodayDate();

html += `
  <button
    class="cal-day ${hasBooking ? "has-booking" : ""} ${selected ? "selected" : ""} ${today ? "today" : ""}"
    onclick="selectCalendarDate('${dateStr}')"
  >
    ${d}
    ${hasBooking ? `<span class="booking-dot"></span>` : ""}
  </button>
`;


  }

  box.innerHTML = html;
}

function selectCalendarDate(dateStr){
  selectedCalendarDate = dateStr;
  renderCustomCalendar();
}

function changeCalendarMonth(step){
  calendarMonth += step;

  if(calendarMonth < 0){
    calendarMonth = 11;
    calendarYear--;
  }

  if(calendarMonth > 11){
    calendarMonth = 0;
    calendarYear++;
  }

  renderCustomCalendar();
}

function closeDatePicker(){
  document.getElementById("datePickerModalBg").style.display = "none";
}

function confirmDatePicker(){
  currentBookingDate = selectedCalendarDate;

  closeDatePicker();
  renderBookingGrid();
  renderList();
}
  


function drawExistingBookings(){
  document.querySelectorAll(".slot-cell.booked, .slot-cell.checked-in-booking").forEach(el=>{
    el.classList.remove("booked","checked-in-booking");
    el.innerHTML = "";
    el.onclick = null;
    el.style.background = "";
    el.style.color = "";
  });

  const slots = getSlots();

  const dayBookings = (state.bookings || []).filter(b=>{
    return (b.date || currentBookingDate) === currentBookingDate;
  });

  dayBookings.forEach(b=>{
    const finished = (b.finishedTableIndexes || []).map(Number);

    const tableIndexes = (b.tableIndexes || [b.tableIndex])
      .filter(v=>v !== undefined && v !== null)
      .map(Number)
      .filter(i=>!finished.includes(i));

    const startRow = slots.indexOf(b.startTime);
    let endRow = slots.indexOf(b.endTime);

    if(startRow < 0) return;

    if(endRow < 0 && b.endTime === `${getBusinessHours().close}:00`){
      endRow = slots.length;
    }

    const realEndRow = endRow > startRow ? endRow : startRow + 1;
    const baseColor = b.color || "#B7E4C7";
    const bgColor = b.checkedIn ? darkenColor(baseColor, 35) : baseColor;

    tableIndexes.forEach(tableIndex=>{
      for(let rowIndex = startRow; rowIndex < realEndRow; rowIndex++){
        const cell = document.querySelector(
          `.slot-cell[data-table="${tableIndex}"][data-row="${rowIndex}"]`
        );

        if(!cell) continue;

        cell.classList.add(b.checkedIn ? "checked-in-booking" : "booked");
        cell.style.background = bgColor;
        cell.style.color = "#332d24";

        cell.onpointerdown = null;
        cell.onpointermove = null;
        cell.onpointerup = null;
        cell.onpointercancel = null;

        cell.onclick = (e)=>{
          e.preventDefault();
          e.stopPropagation();
          if(bookingLocked) return;
          openBookingAction(b.id);
        };

  if(rowIndex === startRow && tableIndex === tableIndexes[0]){
  const phoneLast4 = String(b.phone || "").slice(-4);

  cell.innerHTML = b.checkedIn
    ? ""
    : `
      <div class="booking-cell-name">${b.name || "-"}</div>
      <div class="booking-cell-phone">${phoneLast4 || ""}</div>
    `;
}
               
      }
    });
  });
}

function drawRunningTables(){
  document.querySelectorAll(".running-block").forEach(el=>{
    el.remove();
  });

  state.tables.forEach((t,tableIndex)=>{
    if(!t.start) return;

    const slots = getSlots();

    let startRow = -1;
    let endRow = -1;

    for(let row=0; row<slots.length-1; row++){
      if(isTableBusyAtSlot(t,row)){
        if(startRow === -1) startRow = row;
        endRow = row;
      }
    }

    if(startRow === -1) return;

    const bgColor = darkenColor(getRunningColor(t), 35);

    for(let row=startRow; row<=endRow; row++){
      const cell = document.querySelector(
        `.slot-cell[data-table="${tableIndex}"][data-row="${row}"]`
      );

    if(cell){
  cell.style.background = bgColor;

  cell.onclick = (e)=>{
    e.preventDefault();
    e.stopPropagation();

    if(bookingLocked) return;

    openRunningTablePay(tableIndex);
  };
}      
    }

    const middleRow = Math.floor((startRow + endRow) / 2);

const middleCell = document.querySelector(
  `.slot-cell[data-table="${tableIndex}"][data-row="${middleRow}"]`
);

if(!middleCell) return;

const status = getTableStatusText(t);

middleCell.innerHTML = `
  <div class="running-block ${status.className}">
    <div class="running-time">
      ${status.text}
    </div>
  </div>
`;



      });
}


function openRunningTablePay(tableIndex){
  const t = state.tables[tableIndex];
  if(!t || !t.start) return;

  runningPayTableIndex = tableIndex;

  document.getElementById("runningPayInfo").innerHTML = `
    ${t.name}<br>
    当前付款方式：${t.pay || "未记录"}
  `;

  document.getElementById("runningPaySelect").value = t.pay || "";

  document.getElementById("runningPayModalBg").style.display = "block";
}

function closeRunningTablePay(){
  document.getElementById("runningPayModalBg").style.display = "none";
  runningPayTableIndex = null;
}

async function confirmRunningTablePay(){
  if(runningPayTableIndex === null) return;

  const t = state.tables[runningPayTableIndex];
  const value = document.getElementById("runningPaySelect").value;

  if(!value){
    alert("请选择付款方式");
    return;
  }

  t.pay = value;

if(t.recordId){
  const snap = await getDoc(doc(db, "records", t.recordId));

  if(snap.exists()){
    const r = snap.data();
    r.pay = value;
    await setDoc(doc(db, "records", r.id), r);
  }
}

  save();
  closeRunningTablePay();
  renderBookingGrid();

  alert(`${t.name} 已设置付款方式：${value}`);
}






function getBookingById(id){
  return state.bookings.find(b=>Number(b.id) === Number(id));
}

function openBookingAction(id){
  const b = getBookingById(id);
  if(!b) return;

  activeBookingId = id;

  const tableIndex = Number(
    (b.tableIndexes || [b.tableIndex])[0] || 0
  );

  document.getElementById("bookingActionInfo").innerHTML = `
    时间：${b.startTime} - ${b.endTime}<br>
    状态：${b.checkedIn ? "已到店" : "未到店"}
  `;

  document.getElementById("detailName").value =
    b.name || "";

  document.getElementById("detailPhone").value =
    b.phone || "";

  document.getElementById("detailPay").value =
    b.pay || "";

  const indexes = (b.tableIndexes || [b.tableIndex])
  .filter(v=>v !== undefined && v !== null)
  .map(Number);

document.getElementById("detailTablesBox").innerHTML = `
  <div style="font-weight:800;margin:8px 0;">
    预约桌位：${indexes.map(i=>state.tables[i]?.name).filter(Boolean).join("、")}
  </div>
`;


    document.getElementById("detailPackage").innerHTML =
  (state.packages || []).map((p,i)=>`
    <option value="${i}" ${Number(b.packageIndex || 0) === i ? "selected" : ""}>
      ${p.name}｜${p.unlimited ? "不限时" : p.minutes + "分钟"}｜¥${p.price}
    </option>
  `).join("");

  document.getElementById("bookingActionModalBg").style.display = "block";
}

function saveBookingDetail(){
  const b = getBookingById(activeBookingId);
  if(!b) return;

  const newName = document.getElementById("detailName").value.trim();
  const newPhone = document.getElementById("detailPhone").value.trim();
  const newPay = document.getElementById("detailPay").value;
  const newPackageIndex = Number(document.getElementById("detailPackage").value || 0);

  b.name = newName;
  b.phone = newPhone;
  b.pay = newPay;
  b.packageIndex = newPackageIndex;

  const indexes = (b.tableIndexes || [b.tableIndex])
    .filter(v=>v !== undefined && v !== null)
    .map(Number);

  indexes.forEach(idx=>{
    const t = state.tables[idx];
    if(!t || !t.start) return;

    t.customer = {
      name:newName,
      phoneLast4:String(newPhone || "").slice(-4)
    };

    t.pay = newPay || t.pay || "";
    t.packageIndex = newPackageIndex;
    t.type = "booking";
  });

  save();
  closeBookingAction();
  renderBookingGrid();
  renderList();

  alert("修改成功");
}















function closeBookingAction(){
  document.getElementById("bookingActionModalBg").style.display = "none";
  activeBookingId = null;
}

function openCheckInSelectModal(id){
  const b = getBookingById(id);
  if(!b) return;

  activeBookingId = id;

  const indexes = (b.tableIndexes || [b.tableIndex])
    .filter(v=>v !== undefined && v !== null)
    .map(Number);

  document.getElementById("checkInSelectInfo").innerHTML = `
    ${b.name || "-"}｜${b.startTime || "-"} - ${b.endTime || "-"}<br>
    预约桌位：${indexes.map(i=>state.tables[i]?.name).filter(Boolean).join("、")}
  `;

  document.getElementById("checkInMode").value = "all";

  const box = document.getElementById("checkInTableChecks");
  box.style.display = "none";

  box.innerHTML = indexes.map(i=>`
    <label class="table-check-card">
      <input type="checkbox" class="checkin-table-check" value="${i}" checked>
      ${state.tables[i]?.name || (i+1)+"号桌"}
    </label>
  `).join("");

  document.getElementById("checkInSelectModalBg").style.display = "block";
}

function toggleCheckInMode(){
  const mode = document.getElementById("checkInMode").value;
  const box = document.getElementById("checkInTableChecks");

  box.style.display = mode === "partial" ? "grid" : "none";
}

function closeCheckInSelectModal(){
  document.getElementById("checkInSelectModalBg").style.display = "none";
}

function checkInBooking(){
  openCheckInSelectModal(activeBookingId);
}

async function confirmCheckInSelected(){
  const b = getBookingById(activeBookingId);
  if(!b) return;

  const allIndexes = (b.tableIndexes || [b.tableIndex])
    .filter(v=>v !== undefined && v !== null)
    .map(Number);

  const mode = document.getElementById("checkInMode").value;

  let indexes = allIndexes;

  if(mode === "partial"){
    indexes = [...document.querySelectorAll(".checkin-table-check:checked")]
      .map(el=>Number(el.value));

    if(indexes.length === 0){
      alert("请至少选择一张桌开始计时");
      return;
    }
  }

  const busy = indexes.filter(idx=>state.tables[idx]?.start);

  if(busy.length){
    alert("以下桌位正在使用中，不能开始：\n" + busy.map(i=>state.tables[i].name).join("、"));
    return;
  }

  const now = Date.now();

    for(const idx of indexes){
    const t = state.tables[idx];
    if(!t) return;

    t.type = "booking";
    t.bookingId = b.id;
    t.activeColor = b.color || getNextBookingColor();
    t.customerKey = getCustomerKey(b.name, b.phone);

    t.pay = b.pay || "";
    t.packageIndex = Number(b.packageIndex || 0);

    t.customer = {
      name:b.name || "",
      phoneLast4:String(b.phone || "").slice(-4)
    };

    t.start = now;
    t.pausedAt = null;
    t.alerted = false;
    t.alerting = false;
    t.lastAction = "start";

    await createOrUpdateTableRecord(t, {
  customerType:"booking",
  checkoutMethod:"预约到店开始计时"
});


  }

  if(!b.checkedInTableIndexes){
    b.checkedInTableIndexes = [];
  }

  b.checkedInTableIndexes = Array.from(new Set([
    ...b.checkedInTableIndexes.map(Number),
    ...indexes
  ]));

  b.checkedIn = b.checkedInTableIndexes.length >= allIndexes.length;
  b.checkInTime = b.checkInTime || now;
  b.checkInTimeText = b.checkInTimeText || new Date(now).toLocaleString();

  addCustomerVisit({
    name:b.name,
    phone:b.phone,
    packageIndex:b.packageIndex,
    tableIndexes:indexes,
    startTime:b.startTime,
    endTime:b.endTime
  });

  save();
  closeCheckInSelectModal();
  closeBookingAction();
  renderBookingGrid();
  renderList();
}

function cancelBooking(){
  const b = getBookingById(activeBookingId);
  if(!b) return;

  if(!confirm("确定取消这个预约吗？")) return;

  const indexes = (b.tableIndexes || [b.tableIndex])
    .filter(v=>v !== undefined && v !== null)
    .map(Number);

  indexes.forEach(idx=>{
    const t = state.tables[idx];
    if(!t) return;

    if(
      !t.start &&
      t.type === "booking" &&
      t.customer?.name === b.name &&
      t.customer?.phoneLast4 === String(b.phone || "").slice(-4)
    ){
      t.type = "";
      t.customer = {name:"", phoneLast4:""};
    }
  });

  state.bookings = state.bookings.filter(x=>Number(x.id) !== Number(b.id));

  save();
  closeBookingAction();
  renderBookingGrid();
  renderList();
}

function printBookingGrid(){
  location.href = `./print-booking.html?date=${currentBookingDate}`;
}

window.printBookingGrid = printBookingGrid;
window.openDatePicker = openDatePicker;
window.closeDatePicker = closeDatePicker;
window.confirmDatePicker = confirmDatePicker;
window.renderBookingGrid = renderBookingGrid;
window.startSelectSlot = startSelectSlot;
window.moveSelectSlot = moveSelectSlot;
window.endSelectSlot = endSelectSlot;
window.confirmGridBooking = confirmGridBooking;
window.closeBookingModal = closeBookingModal;
window.moveSelectByPoint = moveSelectByPoint;
window.openBookingAction = openBookingAction;
window.closeBookingAction = closeBookingAction;
window.checkInBooking = checkInBooking;
window.cancelBooking = cancelBooking;
window.saveBookingDetail = saveBookingDetail;
window.toggleBookingLock = toggleBookingLock;
window.changeCalendarMonth = changeCalendarMonth;
window.selectCalendarDate = selectCalendarDate;
window.toggleModalType = toggleModalType;
window.toggleBookingList = toggleBookingList;
window.checkInBookingById = checkInBookingById;
window.cancelBookingById = cancelBookingById;
window.openCheckInSelectModal = openCheckInSelectModal;
window.toggleCheckInMode = toggleCheckInMode;
window.closeCheckInSelectModal = closeCheckInSelectModal;
window.confirmCheckInSelected = confirmCheckInSelected;
window.openMoveTableModal = openMoveTableModal;
window.closeMoveTableModal = closeMoveTableModal;
window.confirmMoveTable = confirmMoveTable;
window.startMoveDrag = startMoveDrag;
window.openRunningTablePay = openRunningTablePay;
window.closeRunningTablePay = closeRunningTablePay;
window.confirmRunningTablePay = confirmRunningTablePay;